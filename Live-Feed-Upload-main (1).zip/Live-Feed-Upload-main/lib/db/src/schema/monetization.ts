import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const monetizationRequestsTable = pgTable("monetization_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("pending"), // pending | approved | rejected
  bankName: text("bank_name").notNull().default(""),
  accountNo: text("account_no").notNull().default(""),
  ifscCode: text("ifsc_code").notNull().default(""),
  mobile: text("mobile").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertMonetizationSchema = createInsertSchema(monetizationRequestsTable).omit({ id: true, createdAt: true, updatedAt: true, status: true });
export type InsertMonetization = z.infer<typeof insertMonetizationSchema>;
export type MonetizationRequest = typeof monetizationRequestsTable.$inferSelect;
