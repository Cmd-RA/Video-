import { pgTable, serial, text, boolean, timestamp } from "drizzle-orm/pg-core";

export const adsenseSettingsTable = pgTable("adsense_settings", {
  id: serial("id").primaryKey(),
  publisherId: text("publisher_id").notNull().default(""),
  headerCode: text("header_code").notNull().default(""),
  slot1Code: text("slot1_code").notNull().default(""),
  slot2Code: text("slot2_code").notNull().default(""),
  slot3Code: text("slot3_code").notNull().default(""),
  isEnabled: boolean("is_enabled").notNull().default(false),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type AdsenseSettings = typeof adsenseSettingsTable.$inferSelect;
