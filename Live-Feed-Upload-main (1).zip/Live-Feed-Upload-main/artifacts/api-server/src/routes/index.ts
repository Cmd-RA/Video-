import { Router, type IRouter } from "express";
import healthRouter from "./health";
import postsRouter from "./posts";
import usersRouter from "./users";
import monetizationRouter from "./monetization";
import adminRouter from "./admin";
import setupRouter from "./setup";

const router: IRouter = Router();

router.use(healthRouter);
router.use(postsRouter);
router.use(usersRouter);
router.use(monetizationRouter);
router.use(adminRouter);
router.use(setupRouter);

export default router;
