import { Router, type IRouter } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

// One-time admin setup — only works if no admin exists yet
router.post("/setup/make-admin", async (req, res) => {
  try {
    const { firebaseUid, secretCode } = req.body as { firebaseUid: string; secretCode: string };

    const SETUP_CODE = process.env.ADMIN_SETUP_CODE || "rajafeed-admin-2024";
    if (secretCode !== SETUP_CODE) {
      res.status(403).json({ error: "Invalid setup code" });
      return;
    }

    // Check if admin already exists
    const [existingAdmin] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.isAdmin, true));

    if (existingAdmin && existingAdmin.firebaseUid !== firebaseUid) {
      res.status(400).json({ error: "Admin already set. Contact current admin." });
      return;
    }

    const [updated] = await db
      .update(usersTable)
      .set({ isAdmin: true })
      .where(eq(usersTable.firebaseUid, firebaseUid))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "User not found. Login first, then try again." });
      return;
    }

    res.json({ success: true, message: `${updated.channelName || updated.email} is now admin!` });
  } catch (err) {
    req.log.error({ err }, "Make admin failed");
    res.status(500).json({ error: "Setup failed" });
  }
});

export default router;
