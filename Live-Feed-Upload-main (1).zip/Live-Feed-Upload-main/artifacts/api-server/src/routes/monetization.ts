import { Router, type IRouter } from "express";
import { db, usersTable, monetizationRequestsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

const ADMIN_UID = process.env.ADMIN_FIREBASE_UID || "";

// Apply for monetization
router.post("/monetization/apply", async (req, res) => {
  try {
    const { uid, bankName, accountNo, ifscCode, mobile } = req.body as {
      uid: string; bankName: string; accountNo: string; ifscCode: string; mobile: string;
    };

    const [user] = await db.select().from(usersTable).where(eq(usersTable.firebaseUid, uid));
    if (!user) { res.status(404).json({ error: "User not found" }); return; }
    if (user.followerCount < 1000) {
      res.status(400).json({ error: "You need at least 1,000 followers to apply." });
      return;
    }

    // Check if already applied
    const [existing] = await db.select().from(monetizationRequestsTable)
      .where(eq(monetizationRequestsTable.userId, user.id));
    if (existing) {
      res.status(400).json({ error: `Application already ${existing.status}.` });
      return;
    }

    await db.insert(monetizationRequestsTable).values({
      userId: user.id,
      bankName,
      accountNo,
      ifscCode,
      mobile,
    });

    res.json({ success: true, message: "Application submitted! Admin will review it soon." });
  } catch (err) {
    req.log.error({ err }, "Apply monetization failed");
    res.status(500).json({ error: "Failed to submit application" });
  }
});

// Admin: get all requests
router.get("/admin/monetization", async (req, res) => {
  try {
    const { adminUid } = req.query as { adminUid: string };
    const [admin] = await db.select().from(usersTable).where(eq(usersTable.firebaseUid, adminUid));
    if (!admin?.isAdmin && adminUid !== ADMIN_UID) {
      res.status(403).json({ error: "Not authorized" }); return;
    }

    const requests = await db
      .select({
        id: monetizationRequestsTable.id,
        userId: monetizationRequestsTable.userId,
        status: monetizationRequestsTable.status,
        bankName: monetizationRequestsTable.bankName,
        accountNo: monetizationRequestsTable.accountNo,
        ifscCode: monetizationRequestsTable.ifscCode,
        mobile: monetizationRequestsTable.mobile,
        channelName: usersTable.channelName,
        email: usersTable.email,
        followerCount: usersTable.followerCount,
        createdAt: monetizationRequestsTable.createdAt,
      })
      .from(monetizationRequestsTable)
      .innerJoin(usersTable, eq(monetizationRequestsTable.userId, usersTable.id));

    res.json(requests.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error({ err }, "Admin get requests failed");
    res.status(500).json({ error: "Failed to get requests" });
  }
});

// Admin: approve
router.post("/admin/monetization/:requestId/approve", async (req, res) => {
  try {
    const { adminUid } = req.body as { adminUid: string };
    const [admin] = await db.select().from(usersTable).where(eq(usersTable.firebaseUid, adminUid));
    if (!admin?.isAdmin && adminUid !== ADMIN_UID) {
      res.status(403).json({ error: "Not authorized" }); return;
    }

    const requestId = parseInt(req.params.requestId);
    const [request] = await db.select().from(monetizationRequestsTable)
      .where(eq(monetizationRequestsTable.id, requestId));
    if (!request) { res.status(404).json({ error: "Request not found" }); return; }

    await db.update(monetizationRequestsTable)
      .set({ status: "approved" })
      .where(eq(monetizationRequestsTable.id, requestId));

    await db.update(usersTable)
      .set({ isMonetized: true })
      .where(eq(usersTable.id, request.userId));

    res.json({ success: true, message: "Approved!" });
  } catch (err) {
    req.log.error({ err }, "Approve failed");
    res.status(500).json({ error: "Approve failed" });
  }
});

// Admin: reject
router.post("/admin/monetization/:requestId/reject", async (req, res) => {
  try {
    const { adminUid } = req.body as { adminUid: string };
    const [admin] = await db.select().from(usersTable).where(eq(usersTable.firebaseUid, adminUid));
    if (!admin?.isAdmin && adminUid !== ADMIN_UID) {
      res.status(403).json({ error: "Not authorized" }); return;
    }

    const requestId = parseInt(req.params.requestId);
    await db.update(monetizationRequestsTable)
      .set({ status: "rejected" })
      .where(eq(monetizationRequestsTable.id, requestId));

    res.json({ success: true, message: "Rejected." });
  } catch (err) {
    req.log.error({ err }, "Reject failed");
    res.status(500).json({ error: "Reject failed" });
  }
});

export default router;
