import { Router, type IRouter } from "express";
import { db, usersTable, followersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

// Register or get user after Google login
router.post("/users/register", async (req, res) => {
  try {
    const { firebaseUid, email, displayName, photoURL } = req.body as {
      firebaseUid: string;
      email: string;
      displayName?: string;
      photoURL?: string;
    };

    // Check if user exists
    const [existing] = await db.select().from(usersTable).where(eq(usersTable.firebaseUid, firebaseUid));
    if (existing) {
      res.json(existing);
      return;
    }

    // Create new user
    const [newUser] = await db.insert(usersTable).values({
      firebaseUid,
      email,
      channelName: displayName || email.split("@")[0],
      profilePhoto: photoURL || "",
      bio: "",
    }).returning();

    res.json(newUser);
  } catch (err) {
    req.log.error({ err }, "Register user failed");
    res.status(500).json({ error: "Failed to register user" });
  }
});

// Get my profile by uid
router.get("/users/me", async (req, res) => {
  try {
    const { uid } = req.query as { uid: string };
    const [user] = await db.select().from(usersTable).where(eq(usersTable.firebaseUid, uid));
    if (!user) { res.status(404).json({ error: "User not found" }); return; }
    res.json(user);
  } catch (err) {
    req.log.error({ err }, "Get profile failed");
    res.status(500).json({ error: "Failed to get profile" });
  }
});

// Update profile
router.put("/users/me", async (req, res) => {
  try {
    const { uid, channelName, bio, profilePhoto } = req.body as {
      uid: string;
      channelName?: string;
      bio?: string;
      profilePhoto?: string;
    };

    const updates: Partial<{ channelName: string; bio: string; profilePhoto: string }> = {};
    if (channelName !== undefined) updates.channelName = channelName;
    if (bio !== undefined) updates.bio = bio;
    if (profilePhoto !== undefined) updates.profilePhoto = profilePhoto;

    const [updated] = await db.update(usersTable)
      .set(updates)
      .where(eq(usersTable.firebaseUid, uid))
      .returning();

    res.json(updated);
  } catch (err) {
    req.log.error({ err }, "Update profile failed");
    res.status(500).json({ error: "Failed to update profile" });
  }
});

// Get user profile by ID
router.get("/users/:userId", async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!user) { res.status(404).json({ error: "User not found" }); return; }
    res.json(user);
  } catch (err) {
    req.log.error({ err }, "Get user failed");
    res.status(500).json({ error: "Failed to get user" });
  }
});

// Follow user
router.post("/users/:userId/follow", async (req, res) => {
  try {
    const followingId = parseInt(req.params.userId);
    const { followerUid } = req.body as { followerUid: string };

    const [followerUser] = await db.select().from(usersTable).where(eq(usersTable.firebaseUid, followerUid));
    if (!followerUser) { res.status(404).json({ error: "Follower not found" }); return; }

    await db.insert(followersTable).values({ followerId: followerUser.id, followingId }).onConflictDoNothing();
    // Update follower count
    await db.update(usersTable)
      .set({ followerCount: sql`${usersTable.followerCount} + 1` })
      .where(eq(usersTable.id, followingId));

    res.json({ success: true, message: "Followed successfully" });
  } catch (err) {
    req.log.error({ err }, "Follow failed");
    res.status(500).json({ error: "Follow failed" });
  }
});

// Unfollow user
router.post("/users/:userId/unfollow", async (req, res) => {
  try {
    const followingId = parseInt(req.params.userId);
    const { followerUid } = req.body as { followerUid: string };

    const [followerUser] = await db.select().from(usersTable).where(eq(usersTable.firebaseUid, followerUid));
    if (!followerUser) { res.status(404).json({ error: "Follower not found" }); return; }

    await db.delete(followersTable)
      .where(sql`${followersTable.followerId} = ${followerUser.id} AND ${followersTable.followingId} = ${followingId}`);

    await db.update(usersTable)
      .set({ followerCount: sql`GREATEST(${usersTable.followerCount} - 1, 0)` })
      .where(eq(usersTable.id, followingId));

    res.json({ success: true, message: "Unfollowed successfully" });
  } catch (err) {
    req.log.error({ err }, "Unfollow failed");
    res.status(500).json({ error: "Unfollow failed" });
  }
});

export default router;
