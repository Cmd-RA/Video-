import { Router, type IRouter } from "express";
import { db, usersTable, postsTable, followersTable, monetizationRequestsTable, adsenseSettingsTable } from "@workspace/db";
import { eq, count, sql, desc } from "drizzle-orm";

const router: IRouter = Router();

const ADMIN_UID = process.env.ADMIN_FIREBASE_UID || "";

async function checkAdmin(uid: string): Promise<boolean> {
  if (!uid) return false;
  if (ADMIN_UID && uid === ADMIN_UID) return true;
  const [user] = await db.select({ isAdmin: usersTable.isAdmin }).from(usersTable).where(eq(usersTable.firebaseUid, uid));
  return user?.isAdmin === true || user?.isAdmin === 1 as unknown as boolean;
}

// ─── Dashboard Stats ──────────────────────────────────────────────────────────
router.get("/admin/stats", async (req, res) => {
  try {
    const { adminUid } = req.query as { adminUid: string };
    if (!await checkAdmin(adminUid)) { res.status(403).json({ error: "Not authorized" }); return; }

    const [totalUsersRes] = await db.select({ cnt: count() }).from(usersTable);
    const [totalPostsRes] = await db.select({ cnt: count() }).from(postsTable);
    const [totalFollowersRes] = await db.select({ cnt: count() }).from(followersTable);
    const [totalMonetizedRes] = await db.select({ cnt: count() }).from(usersTable).where(eq(usersTable.isMonetized, true));

    const monetizationStats = await db.select({
      status: monetizationRequestsTable.status,
      cnt: count(),
    }).from(monetizationRequestsTable).groupBy(monetizationRequestsTable.status);

    const recentUsers = await db.select({
      id: usersTable.id,
      channelName: usersTable.channelName,
      email: usersTable.email,
      followerCount: usersTable.followerCount,
      isMonetized: usersTable.isMonetized,
      createdAt: usersTable.createdAt,
    }).from(usersTable).orderBy(desc(usersTable.createdAt)).limit(10);

    const recentPosts = await db.select({
      id: postsTable.id,
      title: postsTable.title,
      authorName: postsTable.authorName,
      createdAt: postsTable.createdAt,
    }).from(postsTable).orderBy(desc(postsTable.createdAt)).limit(5);

    res.json({
      totalUsers: totalUsersRes.cnt,
      totalPosts: totalPostsRes.cnt,
      totalFollowers: totalFollowersRes.cnt,
      totalMonetized: totalMonetizedRes.cnt,
      monetizationRequests: {
        pending: Number(monetizationStats.find(s => s.status === "pending")?.cnt ?? 0),
        approved: Number(monetizationStats.find(s => s.status === "approved")?.cnt ?? 0),
        rejected: Number(monetizationStats.find(s => s.status === "rejected")?.cnt ?? 0),
      },
      recentUsers: recentUsers.map(u => ({ ...u, createdAt: u.createdAt.toISOString() })),
      recentPosts: recentPosts.map(p => ({ ...p, createdAt: p.createdAt.toISOString() })),
    });
  } catch (err) {
    req.log.error({ err }, "Admin stats failed");
    res.status(500).json({ error: "Failed to get stats" });
  }
});

// ─── User Management ──────────────────────────────────────────────────────────
router.get("/admin/users", async (req, res) => {
  try {
    const { adminUid } = req.query as { adminUid: string };
    if (!await checkAdmin(adminUid)) { res.status(403).json({ error: "Not authorized" }); return; }

    const users = await db.select().from(usersTable).orderBy(desc(usersTable.createdAt));
    res.json(users.map(u => ({ ...u, createdAt: u.createdAt.toISOString() })));
  } catch (err) {
    req.log.error({ err }, "Admin get users failed");
    res.status(500).json({ error: "Failed" });
  }
});

router.delete("/admin/users/:userId", async (req, res) => {
  try {
    const { adminUid } = req.body as { adminUid: string };
    if (!await checkAdmin(adminUid)) { res.status(403).json({ error: "Not authorized" }); return; }
    await db.delete(usersTable).where(eq(usersTable.id, parseInt(req.params.userId)));
    res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Delete user failed");
    res.status(500).json({ error: "Failed" });
  }
});

router.post("/admin/users/:userId/toggle-monetize", async (req, res) => {
  try {
    const { adminUid } = req.body as { adminUid: string };
    if (!await checkAdmin(adminUid)) { res.status(403).json({ error: "Not authorized" }); return; }
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, parseInt(req.params.userId)));
    if (!user) { res.status(404).json({ error: "Not found" }); return; }
    const [updated] = await db.update(usersTable).set({ isMonetized: !user.isMonetized }).where(eq(usersTable.id, user.id)).returning();
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── Post Management ─────────────────────────────────────────────────────────
router.get("/admin/posts", async (req, res) => {
  try {
    const { adminUid } = req.query as { adminUid: string };
    if (!await checkAdmin(adminUid)) { res.status(403).json({ error: "Not authorized" }); return; }
    const posts = await db.select().from(postsTable).orderBy(desc(postsTable.createdAt));
    res.json(posts.map(p => ({ ...p, createdAt: p.createdAt.toISOString() })));
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

router.delete("/admin/posts/:postId", async (req, res) => {
  try {
    const { adminUid } = req.body as { adminUid: string };
    if (!await checkAdmin(adminUid)) { res.status(403).json({ error: "Not authorized" }); return; }
    await db.delete(postsTable).where(eq(postsTable.id, parseInt(req.params.postId)));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── AdSense Management ───────────────────────────────────────────────────────
router.get("/admin/adsense", async (req, res) => {
  try {
    const { adminUid } = req.query as { adminUid: string };
    if (!await checkAdmin(adminUid)) { res.status(403).json({ error: "Not authorized" }); return; }
    const [settings] = await db.select().from(adsenseSettingsTable);
    res.json(settings || { id: null, publisherId: "", headerCode: "", slot1Code: "", slot2Code: "", slot3Code: "", isEnabled: false });
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

router.post("/admin/adsense", async (req, res) => {
  try {
    const { adminUid, publisherId, headerCode, slot1Code, slot2Code, slot3Code, isEnabled } = req.body as {
      adminUid: string; publisherId: string; headerCode: string;
      slot1Code: string; slot2Code: string; slot3Code: string; isEnabled: boolean;
    };
    if (!await checkAdmin(adminUid)) { res.status(403).json({ error: "Not authorized" }); return; }

    const [existing] = await db.select().from(adsenseSettingsTable);
    if (existing) {
      const [updated] = await db.update(adsenseSettingsTable)
        .set({ publisherId, headerCode, slot1Code, slot2Code, slot3Code, isEnabled, updatedAt: new Date() })
        .where(eq(adsenseSettingsTable.id, existing.id))
        .returning();
      res.json(updated);
    } else {
      const [created] = await db.insert(adsenseSettingsTable)
        .values({ publisherId, headerCode, slot1Code, slot2Code, slot3Code, isEnabled })
        .returning();
      res.json(created);
    }
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── Public: Get active AdSense config (no auth needed) ──────────────────────
router.get("/adsense/config", async (_req, res) => {
  try {
    const [settings] = await db.select().from(adsenseSettingsTable).where(eq(adsenseSettingsTable.isEnabled, true));
    if (!settings) { res.json({ isEnabled: false }); return; }
    res.json({
      isEnabled: true,
      publisherId: settings.publisherId,
      headerCode: settings.headerCode,
      slot1Code: settings.slot1Code,
      slot2Code: settings.slot2Code,
      slot3Code: settings.slot3Code,
    });
  } catch (err) {
    res.json({ isEnabled: false });
  }
});

export default router;
