import { Router, type IRouter } from "express";
import multer from "multer";
import axios from "axios";
import FormData from "form-data";
import mongoose from "mongoose";
import { createClient } from "@supabase/supabase-js";
import { db, postsTable } from "@workspace/db";
import { desc } from "drizzle-orm";

const router: IRouter = Router();
const upload = multer({ storage: multer.memoryStorage() });

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "8718819406:AAGv0Q3aVNIVC-CHzwfkGs2Ruv3fkCqJhGU";
const CHANNEL_ID = process.env.TELEGRAM_CHANNEL_ID || "@rajakumar18ni";

// MongoDB setup
if (process.env.MONGO_URI && mongoose.connection.readyState === 0) {
  mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log("MongoDB connected"))
    .catch((e) => console.error("MongoDB error:", e.message));
}

const MongoPostSchema = new mongoose.Schema({
  title: String,
  desc: String,
  imageUrl: String,
  authorName: String,
  authorPhoto: String,
  createdAt: { type: Date, default: Date.now },
});
const MongoPost = mongoose.models["Post"] || mongoose.model("Post", MongoPostSchema);

// Supabase setup
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

router.get("/posts", async (req, res) => {
  try {
    const posts = await db
      .select()
      .from(postsTable)
      .orderBy(desc(postsTable.createdAt));
    res.json(posts.map(p => ({
      id: p.id,
      title: p.title,
      desc: p.desc,
      imageUrl: p.imageUrl,
      authorName: p.authorName,
      authorPhoto: p.authorPhoto || "",
      authorUid: p.authorUid || "",
      createdAt: p.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to fetch posts");
    res.status(500).json({ error: "Failed to fetch posts" });
  }
});

router.post("/posts", upload.single("photo"), async (req, res) => {
  try {
    const { title, desc: description, authorName, authorPhoto, authorUid } = req.body as {
      title: string;
      desc?: string;
      authorName?: string;
      authorPhoto?: string;
      authorUid?: string;
    };

    if (!req.file) {
      res.status(400).json({ error: "Photo is required" });
      return;
    }

    const poster = authorName || "Anonymous";

    // 1. Telegram पर फोटो भेजना
    const formData = new FormData();
    formData.append("chat_id", CHANNEL_ID);
    formData.append("photo", req.file.buffer, { filename: "upload.jpg", contentType: req.file.mimetype });
    formData.append("caption", `<b>${title}</b>\n\n${description || ""}\n\n👤 ${poster}`);
    formData.append("parse_mode", "HTML");

    const teleRes = await axios.post(
      `https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`,
      formData,
      { headers: formData.getHeaders() }
    );

    const photos = teleRes.data.result.photo;
    const fileId = photos[photos.length - 1].file_id;
    const fileInfoRes = await axios.get(
      `https://api.telegram.org/bot${BOT_TOKEN}/getFile?file_id=${fileId}`
    );
    const filePath = fileInfoRes.data.result.file_path;
    const directUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${filePath}`;

    const postData = {
      title,
      desc: description || "",
      imageUrl: directUrl,
      authorName: poster,
      authorPhoto: authorPhoto || "",
      authorUid: authorUid || "",
    };

    // 2. PostgreSQL (main) में save
    const [newPost] = await db
      .insert(postsTable)
      .values(postData)
      .returning();

    // 3. MongoDB में save (background)
    MongoPost.create({ ...postData, createdAt: new Date() })
      .catch((e: Error) => req.log.warn({ err: e }, "MongoDB backup save failed"));

    // 4. Supabase में save (background)
    if (supabase) {
      supabase.from("posts").insert([{
        title,
        description: description || "",
        image_url: directUrl,
        author_name: poster,
        author_photo: authorPhoto || "",
      }]).then(({ error }) => {
        if (error) req.log.warn({ err: error }, "Supabase backup save failed");
      });
    }

    res.status(201).json({
      id: newPost.id,
      title: newPost.title,
      desc: newPost.desc,
      imageUrl: newPost.imageUrl,
      authorName: newPost.authorName,
      authorPhoto: newPost.authorPhoto || "",
      createdAt: newPost.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to upload post");
    const message = err instanceof Error ? err.message : "Upload failed";
    res.status(500).json({ error: `Upload Error: ${message}. Check if Bot is Admin in Channel.` });
  }
});

export default router;
