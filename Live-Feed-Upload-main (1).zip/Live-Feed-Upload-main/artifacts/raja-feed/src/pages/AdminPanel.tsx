import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import {
  Shield, LogIn, Users, FileImage, TrendingUp, DollarSign,
  Check, X, RefreshCw, Trash2, BarChart2, Settings, Code, ChevronDown, ChevronUp,
  Eye, EyeOff, AlertCircle, UserCheck
} from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/hooks/use-toast";

type Tab = "dashboard" | "monetization" | "users" | "posts" | "adsense";

interface Stats {
  totalUsers: number;
  totalPosts: number;
  totalFollowers: number;
  totalMonetized: number;
  monetizationRequests: { pending: number; approved: number; rejected: number };
  recentUsers: Array<{ id: number; channelName: string; email: string; followerCount: number; isMonetized: boolean; createdAt: string }>;
  recentPosts: Array<{ id: number; title: string; authorName: string; createdAt: string }>;
}

interface MonetizationReq {
  id: number; userId: number; status: string; bankName: string;
  accountNo: string; ifscCode: string; mobile: string;
  channelName: string; email: string; followerCount: number; createdAt: string;
}

interface UserRow { id: number; channelName: string; email: string; followerCount: number; isMonetized: boolean; isAdmin: boolean; createdAt: string; }
interface PostRow { id: number; title: string; authorName: string; imageUrl: string; createdAt: string; }
interface AdSense { publisherId: string; headerCode: string; slot1Code: string; slot2Code: string; slot3Code: string; isEnabled: boolean; }

export default function AdminPanel() {
  const { user, signInWithGoogle } = useAuth();
  const { toast } = useToast();
  const [tab, setTab] = useState<Tab>("dashboard");
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState<Stats | null>(null);
  const [monetizationReqs, setMonetizationReqs] = useState<MonetizationReq[]>([]);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [posts, setPosts] = useState<PostRow[]>([]);
  const [adsense, setAdsense] = useState<AdSense>({ publisherId: "", headerCode: "", slot1Code: "", slot2Code: "", slot3Code: "", isEnabled: false });
  const [adsenseSaving, setAdsenseSaving] = useState(false);
  const [processing, setProcessing] = useState<number | null>(null);

  const uid = user?.uid || "";

  const fetchStats = useCallback(async () => {
    const res = await fetch(`/api/admin/stats?adminUid=${uid}`);
    const data = await res.json();
    if (!data.error) setStats(data);
    else toast({ variant: "destructive", title: data.error });
  }, [uid]);

  const fetchMonetization = useCallback(async () => {
    const res = await fetch(`/api/admin/monetization?adminUid=${uid}`);
    const data = await res.json();
    if (Array.isArray(data)) setMonetizationReqs(data);
  }, [uid]);

  const fetchUsers = useCallback(async () => {
    const res = await fetch(`/api/admin/users?adminUid=${uid}`);
    const data = await res.json();
    if (Array.isArray(data)) setUsers(data);
  }, [uid]);

  const fetchPosts = useCallback(async () => {
    const res = await fetch(`/api/admin/posts?adminUid=${uid}`);
    const data = await res.json();
    if (Array.isArray(data)) setPosts(data);
  }, [uid]);

  const fetchAdsense = useCallback(async () => {
    const res = await fetch(`/api/admin/adsense?adminUid=${uid}`);
    const data = await res.json();
    if (!data.error) setAdsense(data);
  }, [uid]);

  const refresh = useCallback(async () => {
    if (!uid) return;
    setLoading(true);
    if (tab === "dashboard") await fetchStats();
    if (tab === "monetization") await fetchMonetization();
    if (tab === "users") await fetchUsers();
    if (tab === "posts") await fetchPosts();
    if (tab === "adsense") await fetchAdsense();
    setLoading(false);
  }, [tab, uid, fetchStats, fetchMonetization, fetchUsers, fetchPosts, fetchAdsense]);

  useEffect(() => { if (user) refresh(); else setLoading(false); }, [user, tab]);

  const handleMonetize = async (id: number, action: "approve" | "reject") => {
    setProcessing(id);
    const res = await fetch(`/api/admin/monetization/${id}/${action}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ adminUid: uid }),
    });
    const data = await res.json();
    setProcessing(null);
    if (data.success) { toast({ title: action === "approve" ? "✅ Approved!" : "❌ Rejected" }); fetchMonetization(); fetchStats(); }
    else toast({ variant: "destructive", title: data.error });
  };

  const handleDeleteUser = async (userId: number) => {
    if (!confirm("Are you sure? This will delete the user and all their data.")) return;
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: "DELETE", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ adminUid: uid }),
    });
    const data = await res.json();
    if (data.success) { toast({ title: "User deleted" }); fetchUsers(); fetchStats(); }
    else toast({ variant: "destructive", title: data.error });
  };

  const handleToggleMonetize = async (userId: number) => {
    const res = await fetch(`/api/admin/users/${userId}/toggle-monetize`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ adminUid: uid }),
    });
    const data = await res.json();
    if (!data.error) { toast({ title: "Updated!" }); fetchUsers(); }
    else toast({ variant: "destructive", title: data.error });
  };

  const handleDeletePost = async (postId: number) => {
    if (!confirm("Delete this post?")) return;
    const res = await fetch(`/api/admin/posts/${postId}`, {
      method: "DELETE", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ adminUid: uid }),
    });
    const data = await res.json();
    if (data.success) { toast({ title: "Post deleted" }); fetchPosts(); fetchStats(); }
    else toast({ variant: "destructive", title: data.error });
  };

  const handleSaveAdsense = async () => {
    setAdsenseSaving(true);
    const res = await fetch("/api/admin/adsense", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ adminUid: uid, ...adsense }),
    });
    const data = await res.json();
    setAdsenseSaving(false);
    if (!data.error) toast({ title: "AdSense settings saved! ✅" });
    else toast({ variant: "destructive", title: data.error });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center pb-24 px-4">
        <Shield className="w-14 h-14 text-primary/30 mb-4" />
        <h2 className="text-xl font-bold text-foreground mb-2">Admin Only</h2>
        <p className="text-muted-foreground text-sm mb-6">Sign in with your admin account</p>
        <button onClick={signInWithGoogle} className="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-colors">
          <LogIn className="w-4 h-4" />Sign in with Google
        </button>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "dashboard", label: "Dashboard", icon: <BarChart2 className="w-4 h-4" /> },
    { id: "monetization", label: "Monetization", icon: <DollarSign className="w-4 h-4" /> },
    { id: "users", label: "Users", icon: <Users className="w-4 h-4" /> },
    { id: "posts", label: "Posts", icon: <FileImage className="w-4 h-4" /> },
    { id: "adsense", label: "AdSense", icon: <Code className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-card border-b border-border sticky top-14 z-40">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            <h1 className="font-bold text-foreground">Admin Panel</h1>
          </div>
          <button onClick={refresh} className="p-2 rounded-lg hover:bg-muted transition-colors">
            <RefreshCw className={`w-4 h-4 text-muted-foreground ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
        {/* Tabs */}
        <div className="max-w-3xl mx-auto px-4 flex gap-1 pb-2 overflow-x-auto scrollbar-none">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${tab === t.id ? "bg-primary text-white" : "text-muted-foreground hover:bg-muted"}`}>
              {t.icon}{t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 pt-5 space-y-4">

        {/* ── DASHBOARD ─────────────────────────────────────────────── */}
        {tab === "dashboard" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: "Total Users", value: stats?.totalUsers ?? "—", icon: <Users className="w-5 h-5" />, color: "text-blue-500 bg-blue-50" },
                { label: "Total Posts", value: stats?.totalPosts ?? "—", icon: <FileImage className="w-5 h-5" />, color: "text-purple-500 bg-purple-50" },
                { label: "Total Followers", value: stats?.totalFollowers ?? "—", icon: <TrendingUp className="w-5 h-5" />, color: "text-green-500 bg-green-50" },
                { label: "Monetized", value: stats?.totalMonetized ?? "—", icon: <DollarSign className="w-5 h-5" />, color: "text-yellow-500 bg-yellow-50" },
              ].map(({ label, value, icon, color }) => (
                <div key={label} className="bg-card rounded-2xl border border-border p-4 flex flex-col gap-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${color}`}>{icon}</div>
                  <p className="text-2xl font-bold text-foreground">{value}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
              ))}
            </div>

            {/* Monetization Summary */}
            <div className="bg-card rounded-2xl border border-border p-5">
              <h3 className="font-bold text-foreground mb-3 flex items-center gap-2"><DollarSign className="w-4 h-4 text-yellow-500" />Monetization Requests</h3>
              <div className="flex gap-4">
                {[
                  { label: "Pending", value: stats?.monetizationRequests.pending ?? 0, color: "text-yellow-600 bg-yellow-50" },
                  { label: "Approved", value: stats?.monetizationRequests.approved ?? 0, color: "text-green-600 bg-green-50" },
                  { label: "Rejected", value: stats?.monetizationRequests.rejected ?? 0, color: "text-red-600 bg-red-50" },
                ].map(({ label, value, color }) => (
                  <div key={label} className={`flex-1 rounded-xl p-3 text-center ${color}`}>
                    <p className="text-xl font-bold">{value}</p>
                    <p className="text-xs font-medium">{label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Users */}
            <div className="bg-card rounded-2xl border border-border p-5">
              <h3 className="font-bold text-foreground mb-3 flex items-center gap-2"><Users className="w-4 h-4 text-blue-500" />Recent Users</h3>
              <div className="space-y-2">
                {(stats?.recentUsers || []).slice(0, 5).map(u => (
                  <div key={u.id} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                    <div>
                      <p className="text-sm font-semibold text-foreground">{u.channelName || "—"}</p>
                      <p className="text-xs text-muted-foreground">{u.email} · {u.followerCount} followers</p>
                    </div>
                    {u.isMonetized && <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-semibold">Monetized</span>}
                  </div>
                ))}
                {(!stats?.recentUsers?.length) && <p className="text-muted-foreground text-sm">No users yet</p>}
              </div>
            </div>

            {/* Recent Posts */}
            <div className="bg-card rounded-2xl border border-border p-5">
              <h3 className="font-bold text-foreground mb-3 flex items-center gap-2"><FileImage className="w-4 h-4 text-purple-500" />Recent Posts</h3>
              <div className="space-y-2">
                {(stats?.recentPosts || []).map(p => (
                  <div key={p.id} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                    <div>
                      <p className="text-sm font-semibold text-foreground truncate max-w-[200px]">{p.title}</p>
                      <p className="text-xs text-muted-foreground">by {p.authorName}</p>
                    </div>
                  </div>
                ))}
                {(!stats?.recentPosts?.length) && <p className="text-muted-foreground text-sm">No posts yet</p>}
              </div>
            </div>
          </motion.div>
        )}

        {/* ── MONETIZATION REQUESTS ─────────────────────────────────── */}
        {tab === "monetization" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <h2 className="font-bold text-foreground">Monetization Requests ({monetizationReqs.length})</h2>
            {monetizationReqs.length === 0 && !loading && (
              <div className="text-center py-12 text-muted-foreground bg-card rounded-2xl border border-border">No requests yet.</div>
            )}
            {monetizationReqs.map((req, i) => (
              <motion.div key={req.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                className="bg-card rounded-2xl border border-border p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-bold text-foreground">{req.channelName}</p>
                    <p className="text-xs text-muted-foreground">{req.email} · {req.followerCount} followers</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-semibold capitalize ${
                    req.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                    req.status === "approved" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                    {req.status}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm p-3 bg-muted/50 rounded-xl mb-3">
                  <p><span className="text-muted-foreground text-xs">Bank</span><br /><span className="font-medium">{req.bankName}</span></p>
                  <p><span className="text-muted-foreground text-xs">Account</span><br /><span className="font-medium">{req.accountNo}</span></p>
                  <p><span className="text-muted-foreground text-xs">IFSC</span><br /><span className="font-medium">{req.ifscCode}</span></p>
                  <p><span className="text-muted-foreground text-xs">Mobile</span><br /><span className="font-medium">{req.mobile}</span></p>
                </div>
                {req.status === "pending" && (
                  <div className="flex gap-2">
                    <button onClick={() => handleMonetize(req.id, "approve")} disabled={processing === req.id}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-green-500 text-white rounded-xl font-semibold text-sm hover:bg-green-600 disabled:opacity-60 transition-colors">
                      <Check className="w-4 h-4" />Approve
                    </button>
                    <button onClick={() => handleMonetize(req.id, "reject")} disabled={processing === req.id}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-destructive text-white rounded-xl font-semibold text-sm hover:bg-destructive/90 disabled:opacity-60 transition-colors">
                      <X className="w-4 h-4" />Reject
                    </button>
                  </div>
                )}
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* ── USERS ─────────────────────────────────────────────────── */}
        {tab === "users" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
            <h2 className="font-bold text-foreground">All Users ({users.length})</h2>
            {users.map((u, i) => (
              <motion.div key={u.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
                className="bg-card rounded-2xl border border-border p-4 flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-foreground text-sm truncate">{u.channelName || "—"}</p>
                    {u.isAdmin && <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded font-semibold">Admin</span>}
                    {u.isMonetized && <span className="text-xs bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded font-semibold">Monetized</span>}
                  </div>
                  <p className="text-xs text-muted-foreground">{u.email} · {u.followerCount} followers</p>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button onClick={() => handleToggleMonetize(u.id)} title={u.isMonetized ? "Remove monetization" : "Grant monetization"}
                    className={`p-2 rounded-lg transition-colors ${u.isMonetized ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-200" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}>
                    <UserCheck className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDeleteUser(u.id)} title="Delete user"
                    className="p-2 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
            {!users.length && !loading && <p className="text-center py-12 text-muted-foreground bg-card rounded-2xl border border-border">No users yet.</p>}
          </motion.div>
        )}

        {/* ── POSTS ─────────────────────────────────────────────────── */}
        {tab === "posts" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
            <h2 className="font-bold text-foreground">All Posts ({posts.length})</h2>
            {posts.map((p, i) => (
              <motion.div key={p.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
                className="bg-card rounded-2xl border border-border p-4 flex items-center gap-3">
                <img src={p.imageUrl} alt={p.title} className="w-14 h-14 rounded-xl object-cover flex-shrink-0 pointer-events-none select-none" onContextMenu={e => e.preventDefault()} />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-sm truncate">{p.title}</p>
                  <p className="text-xs text-muted-foreground">by {p.authorName}</p>
                </div>
                <button onClick={() => handleDeletePost(p.id)} title="Delete post"
                  className="p-2 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors flex-shrink-0">
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
            {!posts.length && !loading && <p className="text-center py-12 text-muted-foreground bg-card rounded-2xl border border-border">No posts yet.</p>}
          </motion.div>
        )}

        {/* ── ADSENSE ───────────────────────────────────────────────── */}
        {tab === "adsense" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <div className="bg-card rounded-2xl border border-border p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-foreground flex items-center gap-2"><Code className="w-5 h-5 text-primary" />Google AdSense Setup</h2>
                <button
                  onClick={() => setAdsense(a => ({ ...a, isEnabled: !a.isEnabled }))}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors ${adsense.isEnabled ? "bg-green-100 text-green-700" : "bg-muted text-muted-foreground"}`}>
                  {adsense.isEnabled ? <><Eye className="w-4 h-4" />Ads ON</> : <><EyeOff className="w-4 h-4" />Ads OFF</>}
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 block">Publisher ID</label>
                  <input value={adsense.publisherId}
                    onChange={e => setAdsense(a => ({ ...a, publisherId: e.target.value }))}
                    placeholder="ca-pub-XXXXXXXXXXXXXXXX"
                    className="w-full px-3 py-2.5 rounded-xl border border-border bg-background text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" />
                </div>

                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    Header Code <span className="text-muted-foreground/50 normal-case font-normal">(paste the full &lt;script&gt; tag from AdSense)</span>
                  </label>
                  <textarea value={adsense.headerCode}
                    onChange={e => setAdsense(a => ({ ...a, headerCode: e.target.value }))}
                    placeholder='<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-..." crossorigin="anonymous"></script>'
                    rows={3}
                    className="w-full px-3 py-2.5 rounded-xl border border-border bg-background text-xs font-mono resize-none focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" />
                </div>

                {[
                  { key: "slot1Code", label: "Ad Slot 1", placeholder: "Paste <ins> ad unit code here..." },
                  { key: "slot2Code", label: "Ad Slot 2 (between posts)", placeholder: "Paste <ins> ad unit code here..." },
                  { key: "slot3Code", label: "Ad Slot 3 (bottom)", placeholder: "Paste <ins> ad unit code here..." },
                ].map(({ key, label, placeholder }) => (
                  <div key={key}>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 block">{label}</label>
                    <textarea value={adsense[key as keyof AdSense] as string}
                      onChange={e => setAdsense(a => ({ ...a, [key]: e.target.value }))}
                      placeholder={placeholder}
                      rows={3}
                      className="w-full px-3 py-2.5 rounded-xl border border-border bg-background text-xs font-mono resize-none focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" />
                    {(adsense[key as keyof AdSense] as string).trim() && (
                      <button onClick={() => setAdsense(a => ({ ...a, [key]: "" }))}
                        className="mt-1 text-xs text-destructive hover:underline flex items-center gap-1">
                        <X className="w-3 h-3" />Clear this slot
                      </button>
                    )}
                  </div>
                ))}

                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-700">AdSense code जोड़ने के बाद <strong>"Save"</strong> करो। Ads ON toggle करो। फिर Firebase Hosting में अपना domain add करके AdSense में submit करो।</p>
                </div>

                <button onClick={handleSaveAdsense} disabled={adsenseSaving}
                  className="w-full py-3 bg-primary text-white rounded-xl font-bold text-sm hover:bg-primary/90 disabled:opacity-60 transition-colors flex items-center justify-center gap-2">
                  <Settings className="w-4 h-4" />{adsenseSaving ? "Saving..." : "Save AdSense Settings"}
                </button>
              </div>
            </div>

            {/* Preview */}
            {adsense.isEnabled && adsense.headerCode && (
              <div className="bg-green-50 border border-green-200 rounded-2xl p-4">
                <p className="text-sm font-semibold text-green-700 mb-1">✅ AdSense is Active</p>
                <p className="text-xs text-green-600">Publisher ID: {adsense.publisherId}</p>
                <p className="text-xs text-green-600 mt-1">Ads will show on Home, Search, and between posts.</p>
              </div>
            )}
          </motion.div>
        )}

        {loading && (
          <div className="text-center py-8 text-muted-foreground text-sm">Loading...</div>
        )}
      </div>
    </div>
  );
}
