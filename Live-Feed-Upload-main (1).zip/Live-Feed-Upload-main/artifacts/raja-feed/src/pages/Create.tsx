import { UploadCard } from "@/components/UploadCard";

export default function CreatePage() {
  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="max-w-2xl mx-auto px-4 pt-6">
        <h1 className="text-2xl font-bold text-foreground mb-6">Create Post</h1>
        <UploadCard />
      </div>
    </div>
  );
}
