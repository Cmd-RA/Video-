import { motion } from "framer-motion";
import { Feed } from "@/components/Feed";
import { Header } from "@/components/Header";
import { Send } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />

      {/* Decorative background */}
      <div className="absolute top-14 left-0 w-full h-[200px] overflow-hidden -z-10 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/8 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-t from-background to-transparent" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-8 pb-4">
        <header className="text-center mb-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-2xl mb-3"
          >
            <Send className="w-7 h-7 text-primary" />
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="text-3xl md:text-4xl font-extrabold tracking-tight text-foreground"
          >
            Raja Digital{" "}
            <span className="text-primary">Feed</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mt-2 text-muted-foreground text-sm max-w-md mx-auto"
          >
            Share photos instantly to the Telegram channel
          </motion.p>
        </header>

        <Feed />
      </div>
    </div>
  );
}
