import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { LogIn, User, Edit2, Save, Shield, DollarSign, Check, X } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { requestNotificationPermission } from "@/lib/firebase";

interface UserProfile {
  id: number;
  channelName: string;
  bio: string;
  profilePhoto: string;
  followerCount: number;
  isMonetized: boolean;
  isAdmin: boolean;
  email: string;
}

export default function ProfilePage() {
  const { user, signInWithGoogle, logout } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [editing, setEditing] = useState(false);
  const [channelName, setChannelName] = useState("");
  const [bio, setBio] = useState("");
  const [saving, setSaving] = useState(false);
  const [showMonetize, setShowMonetize] = useState(false);
  const [bank, setBank] = useState({ bankName: "", accountNo: "", ifscCode: "", mobile: "" });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user) return;
    fetch(`/api/users/me?uid=${user.uid}`)
      .then(r => r.json())
      .then(data => {
        if (!data.error) {
          setProfile(data);
          setChannelName(data.channelName);
          setBio(data.bio);
        }
      });
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    const res = await fetch("/api/users/me", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ uid: user.uid, channelName, bio }),
    });
    const data = await res.json();
    setSaving(false);
    if (!data.error) {
      setProfile(data);
      setEditing(false);
      toast({ title: "Profile updated!" });
    }
  };

  const handleMonetizationApply = async () => {
    if (!user || !bank.bankName || !bank.accountNo || !bank.ifscCode || !bank.mobile) {
      toast({ variant: "destructive", title: "Please fill all bank details" });
      return;
    }
    setSubmitting(true);
    const res = await fetch("/api/monetization/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ uid: user.uid, ...bank }),
    });
    const data = await res.json();
    setSubmitting(false);
    if (data.success) {
      toast({ title: "Application submitted!", description: "Admin will review it soon." });
      setShowMonetize(false);
    } else {
      toast({ variant: "destructive", title: data.error || "Failed" });
    }
  };

  const handleEnableNotifications = async () => {
    const token = await requestNotificationPermission();
    if (token) toast({ title: "Notifications enabled!" });
    else toast({ variant: "destructive", title: "Notifications blocked", description: "Allow notifications in browser settings." });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center pb-24 px-4">
        <div className="text-center">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center text-primary mx-auto mb-4">
            <User className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Sign in to see your profile</h2>
          <p className="text-muted-foreground mb-6">Login with Google to create your channel</p>
          <button
            onClick={signInWithGoogle}
            className="flex items-center gap-2 mx-auto px-6 py-3 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
          >
            <LogIn className="w-5 h-5" />
            Sign in with Google
          </button>
        </div>
      </div>
    );
  }

  const followerCount = profile?.followerCount || 0;
  const canApplyMonetize = followerCount >= 1000 && !profile?.isMonetized;

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="max-w-lg mx-auto px-4 pt-6 space-y-5">
        {/* Profile Card */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          className="bg-card rounded-2xl border border-border p-6 shadow-sm">
          <div className="flex items-start gap-4">
            {user.photoURL ? (
              <img src={user.photoURL} alt="" className="w-16 h-16 rounded-full object-cover ring-2 ring-primary/20 flex-shrink-0" />
            ) : (
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                <User className="w-8 h-8" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              {editing ? (
                <div className="space-y-2">
                  <input value={channelName} onChange={e => setChannelName(e.target.value)}
                    placeholder="Channel Name"
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-primary/20" />
                  <textarea value={bio} onChange={e => setBio(e.target.value)}
                    placeholder="Bio..."
                    rows={2}
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary/20" />
                  <div className="flex gap-2">
                    <button onClick={handleSave} disabled={saving}
                      className="flex items-center gap-1 px-3 py-1.5 bg-primary text-white rounded-lg text-sm font-semibold disabled:opacity-60">
                      <Save className="w-3.5 h-3.5" />{saving ? "Saving..." : "Save"}
                    </button>
                    <button onClick={() => setEditing(false)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-muted text-foreground rounded-lg text-sm font-semibold">
                      <X className="w-3.5 h-3.5" />Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2">
                    <h2 className="font-bold text-foreground text-lg truncate">{profile?.channelName || user.displayName}</h2>
                    {profile?.isMonetized && (
                      <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                        <DollarSign className="w-3 h-3" />Monetized
                      </span>
                    )}
                    {profile?.isAdmin && (
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                        <Shield className="w-3 h-3" />Admin
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{user.email}</p>
                  {profile?.bio && <p className="text-sm text-foreground/80 mt-1">{profile.bio}</p>}
                  <button onClick={() => setEditing(true)}
                    className="mt-2 flex items-center gap-1 text-xs text-primary font-semibold hover:underline">
                    <Edit2 className="w-3 h-3" />Edit Profile
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Follower stats */}
          <div className="mt-4 pt-4 border-t border-border flex items-center gap-6">
            <div className="text-center">
              <p className="text-xl font-bold text-foreground">{followerCount}</p>
              <p className="text-xs text-muted-foreground">Followers</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-bold text-foreground">{profile?.isMonetized ? "✓" : "—"}</p>
              <p className="text-xs text-muted-foreground">Monetized</p>
            </div>
          </div>
        </motion.div>

        {/* Monetization Card */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-card rounded-2xl border border-border p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <DollarSign className="w-5 h-5 text-yellow-500" />
            <h3 className="font-bold text-foreground">Monetization</h3>
          </div>

          {profile?.isMonetized ? (
            <div className="flex items-center gap-2 text-green-600 font-semibold">
              <Check className="w-5 h-5" /> Your channel is monetized!
            </div>
          ) : (
            <>
              <div className="space-y-2 mb-4">
                <div className={`flex items-center gap-2 text-sm ${followerCount >= 1000 ? "text-green-600" : "text-muted-foreground"}`}>
                  {followerCount >= 1000 ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                  1,000 Followers required ({followerCount}/1000)
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Check className="w-4 h-4 text-yellow-500" />
                  Original photos only (no screenshots/Google images)
                </div>
              </div>

              {canApplyMonetize && !showMonetize && (
                <button onClick={() => setShowMonetize(true)}
                  className="w-full py-3 bg-yellow-500 text-white rounded-xl font-bold hover:bg-yellow-600 transition-colors">
                  Apply for Monetization
                </button>
              )}

              {showMonetize && (
                <div className="space-y-3 mt-3 p-4 bg-muted/50 rounded-xl border border-border">
                  <p className="text-sm font-semibold text-foreground">Bank Details</p>
                  {[
                    { key: "bankName", placeholder: "Bank Name" },
                    { key: "accountNo", placeholder: "Account Number" },
                    { key: "ifscCode", placeholder: "IFSC Code" },
                    { key: "mobile", placeholder: "Mobile Number" },
                  ].map(({ key, placeholder }) => (
                    <input key={key}
                      placeholder={placeholder}
                      value={bank[key as keyof typeof bank]}
                      onChange={e => setBank(b => ({ ...b, [key]: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  ))}
                  <div className="flex gap-2">
                    <button onClick={handleMonetizationApply} disabled={submitting}
                      className="flex-1 py-2 bg-primary text-white rounded-lg font-semibold text-sm disabled:opacity-60">
                      {submitting ? "Submitting..." : "Submit Application"}
                    </button>
                    <button onClick={() => setShowMonetize(false)}
                      className="px-4 py-2 bg-muted text-foreground rounded-lg font-semibold text-sm">
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </motion.div>

        {/* Settings */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-card rounded-2xl border border-border p-5 shadow-sm space-y-3">
          <h3 className="font-bold text-foreground">Settings</h3>
          <button onClick={handleEnableNotifications}
            className="w-full py-2.5 rounded-xl border border-border text-sm font-medium text-foreground hover:bg-muted transition-colors text-left px-4">
            🔔 Enable Push Notifications
          </button>
          <button onClick={logout}
            className="w-full py-2.5 rounded-xl border border-destructive/30 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors text-left px-4">
            Sign Out
          </button>
        </motion.div>

        {/* Admin Setup (hidden section) */}
        <AdminSetupSection uid={user.uid} />
      </div>
    </div>
  );
}

function AdminSetupSection({ uid }: { uid: string }) {
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSetup = async () => {
    if (!code.trim()) return;
    setLoading(true);
    const res = await fetch("/api/setup/make-admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ firebaseUid: uid, secretCode: code }),
    });
    const data = await res.json();
    setLoading(false);
    setMsg(data.message || data.error || "");
  };

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
      className="bg-card rounded-2xl border border-border/50 overflow-hidden">
      <button onClick={() => setOpen(o => !o)}
        className="w-full px-5 py-3 text-left text-xs text-muted-foreground/50 hover:text-muted-foreground transition-colors">
        {open ? "▲" : "▼"} Admin Setup
      </button>
      {open && (
        <div className="px-5 pb-4 space-y-2">
          <p className="text-xs text-muted-foreground">Enter secret code to become admin</p>
          <input value={code} onChange={e => setCode(e.target.value)} placeholder="Secret code"
            type="password"
            className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20" />
          <button onClick={handleSetup} disabled={loading}
            className="w-full py-2 bg-primary text-white rounded-lg text-sm font-semibold disabled:opacity-60">
            {loading ? "Setting up..." : "Activate Admin"}
          </button>
          {msg && <p className="text-xs text-center font-medium text-foreground">{msg}</p>}
        </div>
      )}
    </motion.div>
  );
}
