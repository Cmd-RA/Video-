import { useState } from "react";
import { motion } from "framer-motion";
import { Search as SearchIcon, User } from "lucide-react";
import { useGetPosts } from "@workspace/api-client-react";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const { data: posts } = useGetPosts();

  const filtered = posts?.filter(
    (p) =>
      p.title.toLowerCase().includes(query.toLowerCase()) ||
      p.desc.toLowerCase().includes(query.toLowerCase()) ||
      p.authorName.toLowerCase().includes(query.toLowerCase())
  ) || [];

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="max-w-2xl mx-auto px-4 pt-6">
        <h1 className="text-2xl font-bold text-foreground mb-4">Search</h1>

        <div className="relative mb-6">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="search"
            placeholder="Search posts, people..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
          />
        </div>

        {query.trim() === "" ? (
          <p className="text-center text-muted-foreground mt-12">Start typing to search posts...</p>
        ) : filtered.length === 0 ? (
          <p className="text-center text-muted-foreground mt-12">No results found for "{query}"</p>
        ) : (
          <div className="space-y-4">
            {filtered.map((post, i) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex gap-3 p-3 bg-card rounded-xl border border-border hover:border-primary/20 transition-colors"
              >
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="w-16 h-16 rounded-lg object-cover flex-shrink-0 select-none pointer-events-none"
                  onContextMenu={(e) => e.preventDefault()}
                />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-foreground text-sm truncate">{post.title}</p>
                  <p className="text-muted-foreground text-xs line-clamp-2 mt-1">{post.desc}</p>
                  <div className="flex items-center gap-1 mt-2">
                    {post.authorPhoto ? (
                      <img src={post.authorPhoto} alt="" className="w-4 h-4 rounded-full" />
                    ) : (
                      <User className="w-4 h-4 text-muted-foreground" />
                    )}
                    <span className="text-xs text-muted-foreground">{post.authorName}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
