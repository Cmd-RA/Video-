import { motion } from "framer-motion";
import { ImageOff, Loader2, Sparkles } from "lucide-react";
import { useGetPosts } from "@workspace/api-client-react";
import { PostCard } from "./PostCard";
import { AdPlaceholder } from "./AdPlaceholder";

export function Feed() {
  const { data: posts, isLoading, isError, error } = useGetPosts();

  if (isLoading) {
    return (
      <div className="w-full py-16 flex flex-col items-center justify-center text-primary gap-3">
        <Loader2 className="w-9 h-9 animate-spin" />
        <p className="text-muted-foreground text-sm animate-pulse">Loading feed...</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="w-full p-6 rounded-2xl bg-destructive/10 border border-destructive/20 text-center">
        <p className="text-destructive font-semibold">Failed to load feed</p>
        <p className="text-destructive/70 text-sm mt-1">{error?.message}</p>
      </div>
    );
  }

  if (!posts || posts.length === 0) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="w-full py-16 px-6 rounded-2xl border-2 border-dashed border-border bg-card/50 flex flex-col items-center text-center">
        <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-3">
          <ImageOff className="w-7 h-7" />
        </div>
        <h3 className="text-lg font-bold text-foreground">No photos yet</h3>
        <p className="text-muted-foreground text-sm mt-1 max-w-xs">
          Be the first! Go to the Create tab to upload.
        </p>
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          Latest Posts <Sparkles className="w-4 h-4 text-primary" />
        </h2>
        <span className="text-xs font-medium text-muted-foreground bg-card border border-border px-3 py-1 rounded-full">
          {posts.length} {posts.length === 1 ? "post" : "posts"}
        </span>
      </div>

      {/* Top Ad */}
      <AdPlaceholder />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {posts.map((post, index) => (
          <div key={post.id}>
            <PostCard post={post} index={index} />
            {/* Ad every 6 posts */}
            {(index + 1) % 6 === 0 && index !== posts.length - 1 && (
              <div className="col-span-full">
                <AdPlaceholder />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Bottom Ad */}
      <AdPlaceholder />
    </div>
  );
}
