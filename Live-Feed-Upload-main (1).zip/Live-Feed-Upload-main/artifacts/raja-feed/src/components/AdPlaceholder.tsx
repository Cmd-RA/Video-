import { useEffect, useRef } from "react";
import { useAdsense } from "@/lib/useAdsense";

interface AdPlaceholderProps {
  slot?: 1 | 2 | 3;
}

export function AdPlaceholder({ slot = 1 }: AdPlaceholderProps) {
  const config = useAdsense();
  const containerRef = useRef<HTMLDivElement>(null);
  const injected = useRef(false);

  const slotCode = slot === 1 ? config.slot1Code : slot === 2 ? config.slot2Code : config.slot3Code;

  useEffect(() => {
    if (!config.isEnabled || !slotCode || !containerRef.current || injected.current) return;
    injected.current = true;
    containerRef.current.innerHTML = slotCode;

    // Push adsbygoogle
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).adsbygoogle = (window as any).adsbygoogle || [];
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).adsbygoogle.push({});
    } catch {
      // ignore
    }
  }, [config.isEnabled, slotCode]);

  // If ads disabled or no code — show placeholder
  if (!config.isEnabled || !slotCode) {
    return (
      <div className="w-full my-3 rounded-xl border border-dashed border-border bg-muted/20 flex items-center justify-center h-16 text-xs text-muted-foreground/40 font-medium select-none">
        Advertisement
      </div>
    );
  }

  return (
    <div ref={containerRef} className="w-full my-3 overflow-hidden rounded-xl min-h-[60px] flex items-center justify-center" />
  );
}
