import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LogIn, LogOut, Bell, BellOff, User, ChevronDown, Send, CheckCircle2, Shield } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { requestNotificationPermission } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export function Header() {
  const { user, loading, signInWithGoogle, logout } = useAuth();
  const { toast } = useToast();
  const [profileOpen, setProfileOpen] = useState(false);
  const [, navigate] = useLocation();
  const [notifEnabled, setNotifEnabled] = useState(false);
  const [notifLoading, setNotifLoading] = useState(false);

  const handleEnableNotifications = async () => {
    setNotifLoading(true);
    const token = await requestNotificationPermission();
    setNotifLoading(false);
    if (token) {
      setNotifEnabled(true);
      toast({
        title: "Notifications enabled!",
        description: "You'll get notified when new photos are posted.",
      });
    } else {
      toast({
        variant: "destructive",
        title: "Notifications blocked",
        description: "Please allow notifications in your browser settings.",
      });
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await signInWithGoogle();
      toast({ title: "Welcome!", description: "You are now signed in." });
    } catch {
      toast({ variant: "destructive", title: "Login failed", description: "Could not sign in with Google." });
    }
  };

  const handleLogout = async () => {
    await logout();
    setProfileOpen(false);
    toast({ title: "Signed out" });
  };

  return (
    <header className="w-full border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        {/* Logo */}
        <div className="flex items-center gap-2 font-bold text-primary">
          <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
            <Send className="w-4 h-4 text-white ml-0.5" />
          </div>
          <span className="hidden sm:block text-foreground">Raja Feed</span>
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          {/* Notification toggle */}
          <button
            onClick={handleEnableNotifications}
            disabled={notifEnabled || notifLoading}
            title={notifEnabled ? "Notifications on" : "Enable notifications"}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border border-border bg-background hover:bg-muted transition-colors disabled:opacity-60 disabled:cursor-default"
          >
            {notifEnabled ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <span className="hidden sm:block text-green-600">Notifications On</span>
              </>
            ) : notifLoading ? (
              <>
                <Bell className="w-4 h-4 animate-pulse text-primary" />
                <span className="hidden sm:block">Enabling...</span>
              </>
            ) : (
              <>
                <BellOff className="w-4 h-4 text-muted-foreground" />
                <span className="hidden sm:block">Enable Notifications</span>
              </>
            )}
          </button>

          {/* Auth */}
          {loading ? (
            <div className="w-8 h-8 rounded-full bg-muted animate-pulse" />
          ) : user ? (
            <div className="relative">
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-2 px-2 py-1 rounded-xl hover:bg-muted transition-colors"
              >
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || "User"} className="w-8 h-8 rounded-full object-cover ring-2 ring-primary/20" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    <User className="w-4 h-4" />
                  </div>
                )}
                <span className="hidden sm:block text-sm font-medium text-foreground max-w-[120px] truncate">
                  {user.displayName || user.email}
                </span>
                <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${profileOpen ? "rotate-180" : ""}`} />
              </button>

              <AnimatePresence>
                {profileOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 top-full mt-2 w-64 bg-card border border-border rounded-2xl shadow-xl shadow-black/10 overflow-hidden z-50"
                  >
                    <div className="p-4 border-b border-border">
                      <div className="flex items-center gap-3">
                        {user.photoURL ? (
                          <img src={user.photoURL} alt="" className="w-12 h-12 rounded-full object-cover ring-2 ring-primary/20" />
                        ) : (
                          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                            <User className="w-6 h-6" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="font-bold text-foreground truncate">{user.displayName || "User"}</p>
                          <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-2 space-y-0.5">
                      <button
                        onClick={() => { navigate("/admin"); setProfileOpen(false); }}
                        className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-foreground hover:bg-muted transition-colors text-sm font-medium"
                      >
                        <Shield className="w-4 h-4 text-primary" />
                        Admin Panel
                      </button>
                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-destructive hover:bg-destructive/10 transition-colors text-sm font-medium"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <button
              onClick={handleGoogleLogin}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-white text-sm font-bold hover:bg-primary/90 transition-colors shadow-md shadow-primary/20"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign in with Google</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
