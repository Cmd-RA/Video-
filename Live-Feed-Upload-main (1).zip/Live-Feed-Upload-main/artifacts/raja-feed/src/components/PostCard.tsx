import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { Image as ImageIcon, Clock, User, Share2 } from "lucide-react";
import type { Post } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";

interface PostCardProps {
  post: Post;
  index: number;
}

export function PostCard({ post, index }: PostCardProps) {
  const { toast } = useToast();

  let timeAgo = "recently";
  try {
    timeAgo = formatDistanceToNow(new Date(post.createdAt), { addSuffix: true });
  } catch {
    // fallback
  }

  const handleShare = async () => {
    const shareData = {
      title: post.title,
      text: post.desc,
      url: window.location.href,
    };
    if (navigator.share) {
      try { await navigator.share(shareData); } catch { /* cancelled */ }
    } else {
      await navigator.clipboard.writeText(window.location.href);
      toast({ title: "Link copied!", description: "Share it anywhere." });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.06, ease: "easeOut" }}
      className="bg-card rounded-2xl overflow-hidden shadow-sm border border-border/60 group hover:shadow-lg hover:border-primary/20 transition-all duration-300"
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Image — no download, no right-click */}
      <div className="relative aspect-[4/3] w-full bg-muted overflow-hidden select-none">
        {post.imageUrl ? (
          <img
            src={post.imageUrl}
            alt={post.title}
            loading="lazy"
            draggable={false}
            onContextMenu={(e) => e.preventDefault()}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out pointer-events-none select-none"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground/30">
            <ImageIcon className="w-14 h-14" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Author */}
        <div className="flex items-center gap-2 mb-2">
          {post.authorPhoto ? (
            <img src={post.authorPhoto} alt={post.authorName} className="w-6 h-6 rounded-full object-cover ring-1 ring-border pointer-events-none select-none" draggable={false} onContextMenu={e => e.preventDefault()} />
          ) : (
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <User className="w-3 h-3" />
            </div>
          )}
          <span className="text-xs font-semibold text-foreground truncate">{post.authorName || "Anonymous"}</span>
        </div>

        <h3 className="text-base font-bold text-foreground leading-tight line-clamp-2">{post.title}</h3>

        {post.desc && (
          <p className="mt-1.5 text-muted-foreground text-sm leading-relaxed line-clamp-2">{post.desc}</p>
        )}

        {/* Footer */}
        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-1 text-xs text-muted-foreground/60">
            <Clock className="w-3 h-3" />
            <span>{timeAgo}</span>
          </div>

          {/* Share only — no download */}
          <button
            onClick={handleShare}
            className="flex items-center gap-1 text-xs font-semibold text-primary hover:bg-primary/10 px-2.5 py-1.5 rounded-lg transition-colors"
          >
            <Share2 className="w-3.5 h-3.5" />
            Share
          </button>
        </div>
      </div>
    </motion.div>
  );
}
