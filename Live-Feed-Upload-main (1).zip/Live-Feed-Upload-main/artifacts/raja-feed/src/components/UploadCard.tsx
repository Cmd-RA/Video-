import { useState, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Send, ImagePlus, X, Loader2, CheckCircle2, LogIn } from "lucide-react";
import { useCreatePost, getGetPostsQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export function UploadCard() {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user, signInWithGoogle } = useAuth();

  const { mutate: createPost, isPending } = useCreatePost({
    mutation: {
      onSuccess: () => {
        setTitle("");
        setDesc("");
        handleRemoveFile();
        setIsSuccess(true);
        setTimeout(() => setIsSuccess(false), 2000);
        queryClient.invalidateQueries({ queryKey: getGetPostsQueryKey() });
        toast({
          title: "Successfully posted!",
          description: "Your photo has been uploaded and sent to Telegram.",
        });
      },
      onError: (error) => {
        toast({
          variant: "destructive",
          title: "Upload failed",
          description: error.message || "Something went wrong while posting.",
        });
      },
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      if (!selected.type.startsWith("image/")) {
        toast({ variant: "destructive", title: "Invalid file type", description: "Please select an image file." });
        return;
      }
      setFile(selected);
      setPreviewUrl(URL.createObjectURL(selected));
    }
  };

  const handleRemoveFile = () => {
    setFile(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !file) {
      toast({ variant: "destructive", title: "Missing fields", description: "Please provide a title and a photo." });
      return;
    }

    createPost({
      data: {
        title: title.trim(),
        desc: desc.trim() || undefined,
        photo: file,
        authorName: user?.displayName || "Anonymous",
        authorPhoto: user?.photoURL || undefined,
        authorUid: user?.uid || undefined,
      },
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="bg-card w-full rounded-2xl md:rounded-[2rem] p-5 md:p-8 shadow-xl shadow-primary/5 border border-border/60 relative overflow-hidden"
    >
      <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-primary/60 to-primary" />

      {/* User info strip */}
      {user ? (
        <div className="mb-5 flex items-center gap-3 p-3 bg-primary/5 rounded-xl border border-primary/10">
          {user.photoURL ? (
            <img src={user.photoURL} alt="" className="w-9 h-9 rounded-full object-cover ring-2 ring-primary/20" />
          ) : (
            <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary text-sm font-bold">
              {user.displayName?.[0] || "U"}
            </div>
          )}
          <div>
            <p className="text-sm font-semibold text-foreground">{user.displayName || user.email}</p>
            <p className="text-xs text-muted-foreground">Posting as you</p>
          </div>
        </div>
      ) : (
        <div className="mb-5 flex items-center justify-between p-3 bg-muted/50 rounded-xl border border-border">
          <p className="text-sm text-muted-foreground">Posting anonymously</p>
          <button
            type="button"
            onClick={signInWithGoogle}
            className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline"
          >
            <LogIn className="w-3.5 h-3.5" />
            Sign in to show your name
          </button>
        </div>
      )}

      <div className="mb-5 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
          <Send className="w-5 h-5 ml-0.5" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground">New Post</h2>
          <p className="text-sm text-muted-foreground">Share a photo to the Telegram channel</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="What is this photo about? (Title)"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          disabled={isPending}
          className="w-full px-4 py-3.5 bg-background border border-border rounded-xl text-foreground font-medium placeholder:text-muted-foreground/70 placeholder:font-normal focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all disabled:opacity-60"
          required
        />

        <textarea
          placeholder="Add more details... (Description)"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          disabled={isPending}
          rows={2}
          className="w-full px-4 py-3.5 bg-background border border-border rounded-xl text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all resize-none disabled:opacity-60"
        />

        <AnimatePresence mode="popLayout">
          {previewUrl ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative rounded-xl overflow-hidden bg-black/5 aspect-video border border-border group"
            >
              <img src={previewUrl} alt="Preview" className="w-full h-full object-contain" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button
                  type="button"
                  onClick={handleRemoveFile}
                  disabled={isPending}
                  className="bg-destructive text-destructive-foreground p-3 rounded-full hover:scale-105 active:scale-95 transition-transform shadow-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isPending}
                className="w-full py-8 border-2 border-dashed border-border hover:border-primary/50 hover:bg-primary/5 rounded-xl flex flex-col items-center justify-center gap-2 text-muted-foreground hover:text-primary transition-colors cursor-pointer group"
              >
                <div className="p-3 bg-background rounded-full group-hover:bg-white group-hover:shadow-sm transition-all">
                  <ImagePlus className="w-6 h-6" />
                </div>
                <span className="font-medium text-sm">Click to select a photo</span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />

        <button
          type="submit"
          disabled={isPending || !title.trim() || !file || isSuccess}
          className={cn(
            "w-full py-4 rounded-xl font-bold text-white shadow-lg shadow-primary/25 transition-all duration-300 flex items-center justify-center gap-2",
            isSuccess
              ? "bg-green-500 shadow-green-500/25"
              : "bg-primary hover:bg-primary/90 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0 disabled:hover:shadow-primary/25"
          )}
        >
          {isPending ? (
            <><Loader2 className="w-5 h-5 animate-spin" /><span>Uploading...</span></>
          ) : isSuccess ? (
            <><CheckCircle2 className="w-5 h-5" /><span>Posted!</span></>
          ) : (
            <><Send className="w-5 h-5" /><span>Upload & Post</span></>
          )}
        </button>
      </form>
    </motion.div>
  );
}
