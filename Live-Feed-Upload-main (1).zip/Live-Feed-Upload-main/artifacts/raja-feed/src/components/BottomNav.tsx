import { Home, Search, PlusSquare, User } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

const tabs = [
  { label: "Home", icon: Home, path: "/" },
  { label: "Search", icon: Search, path: "/search" },
  { label: "Create", icon: PlusSquare, path: "/create" },
  { label: "Profile", icon: User, path: "/profile" },
];

export function BottomNav() {
  const [location, navigate] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-md border-t border-border shadow-xl shadow-black/5">
      <div className="max-w-md mx-auto flex items-center justify-around h-16 px-2">
        {tabs.map(({ label, icon: Icon, path }) => {
          const isActive = location === path;
          const isCreate = label === "Create";
          return (
            <button
              key={label}
              onClick={() => navigate(path)}
              className={cn(
                "flex flex-col items-center justify-center gap-1 flex-1 h-full transition-all duration-200",
                isCreate
                  ? "relative"
                  : isActive
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              )}
              aria-label={label}
            >
              {isCreate ? (
                <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30 -mt-4 hover:scale-105 active:scale-95 transition-transform">
                  <Icon className="w-6 h-6 text-white" />
                </div>
              ) : (
                <>
                  <Icon className={cn("w-5 h-5 transition-transform", isActive && "scale-110")} />
                  <span className={cn("text-[10px] font-semibold", isActive ? "text-primary" : "text-muted-foreground")}>
                    {label}
                  </span>
                </>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
