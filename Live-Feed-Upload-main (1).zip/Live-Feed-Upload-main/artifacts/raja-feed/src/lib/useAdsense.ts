import { useState, useEffect } from "react";

interface AdsenseConfig {
  isEnabled: boolean;
  publisherId?: string;
  headerCode?: string;
  slot1Code?: string;
  slot2Code?: string;
  slot3Code?: string;
}

let cachedConfig: AdsenseConfig | null = null;
let headerInjected = false;

export function useAdsense() {
  const [config, setConfig] = useState<AdsenseConfig>(cachedConfig || { isEnabled: false });

  useEffect(() => {
    if (cachedConfig) { setConfig(cachedConfig); return; }
    fetch("/api/adsense/config")
      .then(r => r.json())
      .then((data: AdsenseConfig) => {
        cachedConfig = data;
        setConfig(data);

        // Inject header script once
        if (data.isEnabled && data.headerCode && !headerInjected) {
          headerInjected = true;
          const div = document.createElement("div");
          div.innerHTML = data.headerCode;
          const script = div.querySelector("script");
          if (script) {
            const s = document.createElement("script");
            if (script.src) s.src = script.src;
            if (script.async) s.async = true;
            if (script.crossOrigin) s.crossOrigin = script.crossOrigin;
            s.innerHTML = script.innerHTML;
            document.head.appendChild(s);
          }
        }
      })
      .catch(() => setConfig({ isEnabled: false }));
  }, []);

  return config;
}
